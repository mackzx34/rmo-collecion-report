-- phpMyAdmin SQL Dump
-- version 5.2.1deb3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 16, 2024 at 04:34 AM
-- Server version: 10.11.7-MariaDB-4
-- PHP Version: 8.2.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `RMO_REPORT`
--

-- --------------------------------------------------------

--
-- Table structure for table `DATA`
--

CREATE TABLE `DATA` (
  `id` int(11) NOT NULL,
  `rmo_id` int(11) DEFAULT NULL,
  `month_id` int(11) DEFAULT NULL,
  `target` decimal(15,2) DEFAULT NULL,
  `total_collected` decimal(15,2) DEFAULT NULL,
  `balance` decimal(15,2) GENERATED ALWAYS AS (`target` - `total_collected`) VIRTUAL,
  `percentage_balance` decimal(5,2) GENERATED ALWAYS AS (100 - `total_collected` / `target` * 100) VIRTUAL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `MONTHS`
--

CREATE TABLE `MONTHS` (
  `id` int(11) NOT NULL,
  `month_name` varchar(50) NOT NULL,
  `year` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `MONTHS`
--

INSERT INTO `MONTHS` (`id`, `month_name`, `year`) VALUES
(100, 'January', '2024'),
(101, 'February', '2024'),
(102, 'March', '2024'),
(103, 'April', '2024'),
(104, 'May', '2024'),
(105, 'June', '2024'),
(106, 'July', '2024'),
(107, 'August', '2024'),
(108, 'September', '2024'),
(109, 'October', '2024'),
(110, 'November', '2024'),
(111, 'December', '2024');

-- --------------------------------------------------------

--
-- Table structure for table `RMO_OFFICE`
--

CREATE TABLE `RMO_OFFICE` (
  `id` int(11) NOT NULL,
  `office_name` varchar(50) NOT NULL,
  `office_location` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `RMO_OFFICE`
--

INSERT INTO `RMO_OFFICE` (`id`, `office_name`, `office_location`) VALUES
(100, 'Arusha', 'Arusha'),
(101, 'Kagera', 'Kagera'),
(102, 'Chunya', 'Mbeya'),
(103, 'Dodoma', 'Dodoma'),
(104, 'Geita', 'Geita'),
(105, 'Handeni', 'Tanga'),
(106, 'Kahama', 'Shinyanga'),
(107, 'Kigoma', 'Kigoma'),
(108, 'Mbeya', 'Mbeya'),
(109, 'Mererani-RMO', 'Manyara'),
(110, 'kilimanjaro', 'Kilimanjaro'),
(111, 'Katavi', 'Katavi');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_roles`
--

CREATE TABLE `tbl_roles` (
  `id` int(11) NOT NULL COMMENT 'role_id',
  `role` varchar(255) DEFAULT NULL COMMENT 'role_text'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_roles`
--

INSERT INTO `tbl_roles` (`id`, `role`) VALUES
(1, 'Admin'),
(2, 'User');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `RMO_OFFICE_NAME` varchar(50) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `mobile` varchar(25) DEFAULT NULL,
  `roleid` tinyint(4) DEFAULT NULL,
  `isActive` tinyint(4) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `fname`, `lname`, `username`, `email`, `RMO_OFFICE_NAME`, `password`, `mobile`, `roleid`, `isActive`, `created_at`, `updated_at`) VALUES
(7, 'admin', 'mduma', 'admin', 'nababurbd@gmail.com', 'Tanga', '$2a$12$aTS/v4391SsXI6VWBp2WrODEi5OaOGzUMajniA3RMa0DCW69L3SHa', '01717090233', 1, 1, '2020-03-12 16:23:01', '2020-03-12 16:23:01'),
(12, 'John', 'ally', 'Rayhan', 'rayhankabir@gmail.com', 'Mererani', '188000e1f0fb4075ae1c659697b96296f982cdc4', '01717090233', 2, 0, '2020-03-12 18:20:24', '2020-03-12 18:20:24'),
(22, 'Joseph', 'Roja', 'joseph.roja', 'josephroja99@gmail.com', 'Dodoma', '$2y$10$mO7qiASp8qKJnLlq1U0Gh.oSIx/8BKlwlaQMm.1lpac.jFqUJ6LMC', '0747793489', 2, 1, '2024-08-15 12:28:00', '2024-08-15 12:28:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `DATA`
--
ALTER TABLE `DATA`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rmo_id` (`rmo_id`),
  ADD KEY `month_id` (`month_id`);

--
-- Indexes for table `MONTHS`
--
ALTER TABLE `MONTHS`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `RMO_OFFICE`
--
ALTER TABLE `RMO_OFFICE`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_roles`
--
ALTER TABLE `tbl_roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `DATA`
--
ALTER TABLE `DATA`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100;

--
-- AUTO_INCREMENT for table `MONTHS`
--
ALTER TABLE `MONTHS`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=112;

--
-- AUTO_INCREMENT for table `RMO_OFFICE`
--
ALTER TABLE `RMO_OFFICE`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=112;

--
-- AUTO_INCREMENT for table `tbl_roles`
--
ALTER TABLE `tbl_roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'role_id', AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `DATA`
--
ALTER TABLE `DATA`
  ADD CONSTRAINT `DATA_ibfk_1` FOREIGN KEY (`rmo_id`) REFERENCES `RMO_OFFICE` (`id`),
  ADD CONSTRAINT `DATA_ibfk_2` FOREIGN KEY (`month_id`) REFERENCES `MONTHS` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
