-- phpMyAdmin SQL Dump
-- version 5.2.1deb3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 16, 2024 at 04:34 AM
-- Server version: 10.11.7-MariaDB-4
-- PHP Version: 8.2.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `umspsdb`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_adminchangepwd` (`newpwd` VARCHAR(120), `ldtime` VARCHAR(120), `uid` INT(5))   BEGIN
update tbladmin set Password=newpwd,updationDate=ldtime where id=uid$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_admincurrentpwdvalidate` (`currentpwd` VARCHAR(120), `uid` INT(5))   BEGIN
select id from tbladmin where id=uid and Password=currentpwd$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_admindashboard` ()   BEGIN
select count(id) as totalusers,
COUNT(IF((date(RegDate)=CURDATE()),0,NULL)) as todayreguser,
COUNT(IF((date(RegDate)=CURDATE()-1),0,NULL)) as yesterdayreguser,
COUNT(IF((date(RegDate) BETWEEN CURDATE() - INTERVAL 7 DAY AND CURDATE()),0,NULL)) as lastsevendaysreguser,
COUNT(IF((date(RegDate) BETWEEN CURDATE() - INTERVAL 30 DAY AND CURDATE()),0,NULL)) as lastthirtydaysreguser
from tblusers$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_adminlogin` (IN `username` VARCHAR(200), IN `adminpwd` VARCHAR(200))   BEGIN
select FullName,id,UserName	 from tbladmin where UserName=username and Password=adminpwd$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_adminpasswordrecovery` (`uname` VARCHAR(120), `adminemail` VARCHAR(200), `newpwd` VARCHAR(150), `ldtime` VARCHAR(120))   BEGIN
update tbladmin set Password=newpwd,updationDate=ldtime  where  UserName=uname and AdminEmail=adminemail$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_adminprofile` (`adminid` INT(5))   BEGIN
select * from tbladmin where id=adminid$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_adminpwdrecoveryvalidation` (`uname` VARCHAR(120), `adminemail` VARCHAR(150))   BEGIN
select id from tbladmin where UserName=uname and AdminEmail=adminemail$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_allregisteredusers` ()   BEGIN
select * from tblusers$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_checkemailavailabilty` (`emalid` VARCHAR(150))   BEGIN
select EmailId from tblusers where EmailId=emalid$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_recent15users` ()   BEGIN
select * from tblusers order by id desc limit 15$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_signup` (IN `p_fname` VARCHAR(50), IN `p_mname` VARCHAR(50), IN `p_lname` VARCHAR(50), IN `p_username` VARCHAR(50), IN `p_email` VARCHAR(100), IN `p_password` VARCHAR(255), IN `p_isactve` TINYINT(1))   BEGIN
    -- Check if the username already exists
    IF (SELECT COUNT(*) FROM tblusers WHERE username = p_username) > 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Username already exists'$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_userchangepwd` (`newpwd` VARCHAR(120), `ldtime` VARCHAR(120), `uid` INT(5))   BEGIN
update tblusers set UserPassword=newpwd,LastUpdationDate=ldtime where id=uid$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_usercurrentpwdvalidate` (`currentpwd` VARCHAR(120), `uid` INT(5))   BEGIN
select id from tblusers where id=uid and UserPassword=currentpwd$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_userdeletion` (`uid` INT(5))   BEGIN
delete  from tblusers where id=uid$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_useremailupdation` (`newemail` VARCHAR(120), `ldtime` VARCHAR(120), `uid` INT(5))   BEGIN
update tblusers set EmailId=newemail,LastUpdationDate=ldtime where id=uid$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_userlogin` (IN `uemailid` VARCHAR(200), IN `userpwd` VARCHAR(200))   BEGIN
select FirstName,LastName,id from tblusers where EmailId=uemailid and UserPassword=userpwd$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_userpasswordrecovery` (`lastname` VARCHAR(120), `useremailid` VARCHAR(200), `newpwd` VARCHAR(150), `ldtime` VARCHAR(120))   BEGIN
update tblusers set UserPassword=newpwd,LastUpdationDate=ldtime  where LastName=lastname and EmailId=useremailid$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_userprofile` (`uid` INT(5))   BEGIN
select * from tblusers where id=uid$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_userpwdrecoveryvalidation` (`lastname` VARCHAR(120), `useremail` VARCHAR(150))   BEGIN
select id from tblusers where LastName=lastname and EmailId=useremail$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_userupdateprofile` (`fname` VARCHAR(120), `lname` VARCHAR(120), `ldtime` VARCHAR(120), `uid` INT(5))   BEGIN
update tblusers set FirstName=fname,LastName=lname,LastUpdationDate=ldtime where id=uid$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `job_titles`
--

CREATE TABLE `job_titles` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `job_titles`
--

INSERT INTO `job_titles` (`id`, `title`) VALUES
(1, 'Geologist'),
(2, 'Mining Engineer'),
(3, 'Environmental Officer'),
(4, 'Safety Officer'),
(5, 'Surveyor'),
(6, 'Metallurgist'),
(7, 'Mine Manager'),
(8, 'Data Analyst'),
(9, 'Finance Officer'),
(10, 'Procurement Officer');

-- --------------------------------------------------------

--
-- Table structure for table `markets`
--

CREATE TABLE `markets` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `markets`
--

INSERT INTO `markets` (`id`, `name`) VALUES
(1, 'Kahama Mineral Market'),
(2, 'Geita Mineral Market'),
(3, 'Mwanza Mineral Market'),
(4, 'Shinyanga Mineral Market'),
(5, 'Arusha Mineral Market'),
(6, 'Dar es Salaam Mineral Market'),
(7, 'Mbeya Mineral Market'),
(8, 'Morogoro Mineral Market'),
(9, 'Iringa Mineral Market'),
(10, 'Dodoma Mineral Market');

-- --------------------------------------------------------

--
-- Table structure for table `otp_storage`
--

CREATE TABLE `otp_storage` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `otp` varchar(6) NOT NULL,
  `expiry` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `otp_storage`
--

INSERT INTO `otp_storage` (`id`, `username`, `email`, `otp`, `expiry`) VALUES
(26, 'admin', 'josephroja99@gmail.com', '564760', '2024-08-08 12:12:43'),
(27, 'admin', 'josephroja99@gmail.com', '445765', '2024-08-08 12:12:45'),
(28, 'admin', 'josephroja99@gmail.com', '868921', '2024-08-08 12:12:45'),
(29, 'admin', 'josephroja99@gmail.com', '896709', '2024-08-08 12:12:46'),
(30, 'admin', 'josephroja99@gmail.com', '442091', '2024-08-08 12:12:46'),
(31, 'admin', 'josephroja99@gmail.com', '971577', '2024-08-08 12:18:46'),
(32, 'admin', 'josephroja99@gmail.com', '246032', '2024-08-08 12:38:55'),
(33, 'admin', 'josephroja99@gmail.com', '558747', '2024-08-08 12:40:59'),
(34, 'admin', 'josephroja99@gmail.com', '432691', '2024-08-08 12:46:58'),
(35, 'admin', 'josephroja99@gmail.com', '284018', '2024-08-08 13:03:28'),
(36, 'admin', 'josephroja99@gmail.com', '261213', '2024-08-08 13:45:04'),
(37, 'admin', 'josephroja99@gmail.com', '147500', '2024-08-08 15:58:52'),
(38, 'admin', 'josephroja99@gmail.com', '314127', '2024-08-08 16:32:05'),
(39, 'admin', 'josephroja99@gmail.com', '451658', '2024-08-08 16:33:14'),
(40, 'admin', 'josephroja99@gmail.com', '606256', '2024-08-08 16:35:10'),
(41, 'admin', 'josephroja99@gmail.com', '767195', '2024-08-09 16:26:31'),
(42, 'admin', 'josephroja99@gmail.com', '161178', '2024-08-09 16:36:59'),
(43, 'admin', 'josephroja99@gmail.com', '643173', '2024-08-09 16:44:06'),
(44, 'admin', 'josephroja99@gmail.com', '504956', '2024-08-09 16:57:37'),
(45, 'admin', 'josephroja99@gmail.com', '940716', '2024-08-09 08:08:12'),
(46, 'admin', 'josephroja99@gmail.com', '629854', '2024-08-09 18:01:31'),
(47, 'admin', 'josephroja99@gmail.com', '112510', '2024-08-11 09:14:50'),
(48, 'admin', 'josephroja99@gmail.com', '245986', '2024-08-11 18:10:41'),
(49, 'jessy', 'joecraig200@gmail.com', '489529', '2024-08-11 14:01:31'),
(50, 'jessy', 'joecraig200@gmail.com', '833983', '2024-08-11 14:42:52'),
(51, 'jessy', 'joecraig200@gmail.com', '731199', '2024-08-11 14:48:03'),
(52, 'makambako', 'joecraig200@gmail.com', '921937', '2024-08-12 01:15:15'),
(53, 'makambako', 'joecraig200@gmail.com', '912309', '2024-08-12 01:20:22'),
(54, 'manditi', 'joecraig200@gmail.com', '862134', '2024-08-12 01:25:11'),
(55, 'USAGEJA', 'joecraig200@gmail.com', '305774', '2024-08-12 02:07:31'),
(60, 'admin', 'josephroja99@gmail.com', '749187', '2024-08-12 02:52:15');

-- --------------------------------------------------------

--
-- Table structure for table `regional_offices`
--

CREATE TABLE `regional_offices` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `regional_offices`
--

INSERT INTO `regional_offices` (`id`, `name`) VALUES
(1, 'Mwanza Regional Office'),
(2, 'Arusha Regional Office'),
(3, 'Dar es Salaam Regional Office'),
(4, 'Mbeya Regional Office'),
(5, 'Morogoro Regional Office'),
(6, 'Iringa Regional Office'),
(7, 'Dodoma Regional Office'),
(8, 'Kigoma Regional Office'),
(9, 'Tabora Regional Office'),
(10, 'Tanga Regional Office');

-- --------------------------------------------------------

--
-- Table structure for table `Roles`
--

CREATE TABLE `Roles` (
  `id` int(11) NOT NULL,
  `role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Roles`
--

INSERT INTO `Roles` (`id`, `role`) VALUES
(1, 'Admin'),
(2, 'User');

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `id` int(11) NOT NULL,
  `FullName` varchar(100) DEFAULT NULL,
  `AdminEmail` varchar(120) DEFAULT NULL,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `updationDate` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`id`, `FullName`, `AdminEmail`, `UserName`, `Password`, `updationDate`) VALUES
(1, 'Mr. Admin', 'josephroja@gmail.com', 'admin', '$2y$10$C1uTwlxaeKpSHTkIQCwRJerRbpSvFcdoE0PnhErEHARXXAJQZWmSe', '06-08-2024 07:54:22 PM');

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `id` int(11) NOT NULL,
  `FirstName` varchar(150) DEFAULT NULL,
  `LastName` varchar(150) DEFAULT NULL,
  `mname` varchar(30) DEFAULT NULL,
  `EmailId` varchar(255) DEFAULT NULL,
  `UserPassword` varchar(255) DEFAULT NULL,
  `RegDate` timestamp NULL DEFAULT current_timestamp(),
  `IsActive` int(1) DEFAULT NULL,
  `LastUpdationDate` varchar(150) DEFAULT NULL,
  `username` varchar(30) NOT NULL,
  `job_title` int(11) DEFAULT NULL,
  `mobile_number` varchar(16) DEFAULT NULL,
  `regional_office` int(11) DEFAULT NULL,
  `market` int(11) DEFAULT NULL,
  `role` varchar(12) DEFAULT NULL,
  `sex` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`id`, `FirstName`, `LastName`, `mname`, `EmailId`, `UserPassword`, `RegDate`, `IsActive`, `LastUpdationDate`, `username`, `job_title`, `mobile_number`, `regional_office`, `market`, `role`, `sex`) VALUES
(17, 'Boniphace', 'Jadi', 'Charlse', 'adminmadini@gmail.com', '$2y$10$rGM0E4OYVtpa9jg9wqaFL.Ls.myXBDm1z/2azXlPV41Ir9Vkmrxra', '2024-08-06 11:58:30', 1, NULL, 'maganga', 4, '0747793489', 8, 7, '1', 'male'),
(18, 'Marko', 'Mdoe', 'Genious', 'mdoejuni@gmail.com', '$2y$10$EjJXned0F.zMoclJ5BPjoueETfH71lD/shuINLkhGuFntcVi33jxi', '2024-08-06 12:21:14', 0, '2024-08-09 16:00:10', 'mdoe', 6, '0694342049', 7, 5, '1', 'male'),
(21, 'Salimu', 'Kachemela', 'Hajis', 'salimkachemela34@gmail.com', '$2y$10$dulO82C7sbCBJfXsUG3SNOJYKeBeZjuh4LZ2i2.T1WEzdN6YOwUgC', '2024-08-06 20:51:55', 1, NULL, 'kachemela', 4, '0764748476', 7, 10, '1', 'male'),
(22, 'Juma', 'Mduma', 'Ally', 'mduma@gmail.com', '$2y$10$WXy2UKZY2IBuQ3Ae3p0HsOK7tG.c16SfPK4BfvOpRDpyt13g4MuvO', '2024-08-07 06:33:54', 1, NULL, 'mduma', 3, '0764748476', 3, 6, '2', 'male'),
(24001, 'Ally ', 'Marando', 'Juma', 'marando123@gmail.com', '$2y$10$GWPznlSYNX6H1/wQEnpGW.sKFXbsOsS2p5HwWBwOZJylThJCF2axW', '2024-08-09 13:05:11', 1, '2024-08-10 19:58:41', 'marando', 7, '0786563445', 3, 7, '1', 'male'),
(24002, 'Abel', 'Mbuya', 'John', 'abelmbuya@gmail.com', '$2y$10$ssxFjJZgzj9ua0Rwcj080OXew0h/Hg9mYZz90Zat8P8LQngiXHoWK', '2024-08-11 12:02:10', 1, NULL, 'Mbuya', NULL, NULL, NULL, NULL, NULL, NULL),
(24004, 'Zacharia', 'Gibore', 'Roja', 'matinde26@gmail.com', '$2y$10$rEIzNQP3Ks21bdnxgoszuOXDZ.D7jXEnf7xVKYnY4Y7dSdLAUEiba', '2024-08-11 12:25:37', 0, NULL, 'matinde', NULL, NULL, NULL, NULL, NULL, NULL),
(24015, 'fatma', 'jadi', 'said', 'papaaofindia@gmail.com', '$2y$10$iI6apIha.Vr3f5AwVfstXeeb9OpbxFm4rrM..z9l8y.52.hTgYLQa', '2024-08-12 09:10:08', 1, NULL, 'jadizo', NULL, NULL, NULL, NULL, NULL, NULL),
(24016, 'Joseph', 'Roja', 'Zacharia', 'josephroja99@gmail.com', '$2y$10$nmfZYdQFd54BHX.DdbBNjeATeSgnNMQhyDBQx6RmKLHNzO8msrMwq', '2024-08-12 09:19:22', 1, NULL, 'joe', NULL, NULL, NULL, NULL, NULL, NULL),
(24017, 'Nani', 'Ally', 'Mzee', 'nani@gmail.com', '$2y$10$IuiHEmyofrmpolDWHdew5uC/CH69ZP3TiLohQ/4cb159xGp33tEuW', '2024-08-12 09:46:43', 1, NULL, 'nani.ally', NULL, NULL, NULL, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `job_titles`
--
ALTER TABLE `job_titles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `markets`
--
ALTER TABLE `markets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `otp_storage`
--
ALTER TABLE `otp_storage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `regional_offices`
--
ALTER TABLE `regional_offices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Roles`
--
ALTER TABLE `Roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `job_titles`
--
ALTER TABLE `job_titles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `markets`
--
ALTER TABLE `markets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `otp_storage`
--
ALTER TABLE `otp_storage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `regional_offices`
--
ALTER TABLE `regional_offices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `Roles`
--
ALTER TABLE `Roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblusers`
--
ALTER TABLE `tblusers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24018;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
